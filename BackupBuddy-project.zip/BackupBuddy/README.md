# BackupBuddy 1.0

Open-source Android backup-monitoring starter app.

## Current implementation status

This project provides a Compose dashboard, local folder monitoring setup, and a foundation for backup-status history. It does **not** verify cloud-provider backups or Android system backups. A folder's existence or recent modification time is not proof that a backup exists.

## Build

- JDK 17
- Android SDK 35
- Gradle 8.9 (GitHub Actions configures this)

Open the project in Android Studio and run the app, or run `gradle assembleDebug` where Android SDK is configured. The debug APK is expected at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

Push to `main`, open a pull request, or manually run the Android Build workflow. On success, download the `BackupBuddy-debug-apk` artifact from the workflow run.

## Privacy

No account, analytics, ads, or remote upload is implemented in this starter.

## License

MIT
